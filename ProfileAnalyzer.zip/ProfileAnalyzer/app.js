var express = require("express");
var cors = require("cors");
var bodyParser = require("body-parser");
var app = express();
var execSync = require('child_process').execSync;
var fs = require("fs");

var projections = [];

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use(function(req, res, next) {
	console.log(`${req.method} request for '${req.url}' - ${JSON.stringify(req.body)}`);
	next();
});

app.use(express.static("./public"));

app.use(cors());

app.get("/analyzer-api", function(req, res) {
	res.json(projections);
});

app.post("/analyzer-api", function(req, res) {
//    var py = execSync(`python mainapp.py ${req.body.github} ${req.body.linkedin}`)
    var contents = fs.readFileSync("output.json");
    var jsonContent = JSON.parse(contents);

    projections.push({
        title: "Your projected salary is: ",
        salary: "$".concat(jsonContent.salary),
        github: "",
        linkedin: "",
        end: "Suggested jobs:"
    });

    if(jsonContent.similar[0].job !== '-') {
        projections.push({
            title: jsonContent.similar[0].job,
            salary: "$".concat(jsonContent.similar[0].salary),
            github: jsonContent.similar[0].githublink,
            linkedin: jsonContent.similar[0].linkedinlink,
            end: ""
        });
    }
    
    if(jsonContent.similar[1].job !== '-') {
        projections.push({
            title: jsonContent.similar[1].job,
            salary: "$".concat(jsonContent.similar[1].salary),
            github: jsonContent.similar[1].githublink,
            linkedin: jsonContent.similar[1].linkedinlink,
            end: ""
        });
    }

    if(jsonContent.similar[2].job !== '-') {
        projections.push({
            title: jsonContent.similar[2].job,
            salary: "$".concat(jsonContent.similar[2].salary),
            github: jsonContent.similar[2].githublink,
            linkedin: jsonContent.similar[2].linkedinlink,
            end: ""
        });
    }

    if (projections.length === 1) {
        projections[0].linkedin = "";
    }

//    console.log(projections);
    
    res.json(projections);
});

app.listen(3000);

console.log("Express app running on port 3000");

module.exports = app;