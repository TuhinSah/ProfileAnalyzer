$(document).ready(function () {

    $.getJSON('/analyzer-api', printProjections);
    $('form').submit(function (e) {
        e.preventDefault();
        $.post('/analyzer-api', {github: $('#github').val(), linkedin: $('#linkedin').val()}, printProjections);
        this.reset();
    });

});

function printProjections(projections) {
    $('body>ul').empty();
    // $('<dt>').text('Projected Salary:').appendTo('body>dl');
    // $('<dd>').text(projections.salary).appendTo('body>dl');
    $.each(projections, function () {
        $('<dt>').text(this.title).appendTo('body>ul');
        $('<dd>').text(this.salary).appendTo('body>ul');
        $('<dd>').text(this.github).appendTo('body>ul');
        $('<dd>').text(this.linkedin).appendTo('body>ul');
        $('<dt>').text(this.end).appendTo('body>ul');
        $('<dd>').text(this.post).appendTo('body>ul');
    });
}
